// FragmentationModel.h is a part of the PYTHIA event generator.
// Copyright (C) 2021 Torbjorn Sjostrand.
// PYTHIA is licenced under the GNU GPL v2 or later, see COPYING for details.
// Please respect the MCnet Guidelines, see GUIDELINES for details.

// This file contains the classes for string fragmentation.
// StringEnd: keeps track of the fragmentation step.
// FragmentationModel: is the top-level class.

#ifndef Pythia8_FragmentationModel_H
#define Pythia8_FragmentationModel_H

#include "Pythia8/SharedPointers.h"
#include "Pythia8/PhysicsBase.h"
#include "Pythia8/FragmentationSystems.h"

namespace Pythia8 {

//==========================================================================

// The FragmentationModel class contains the top-level routines
// to fragment a colour singlet partonic system.

class FragmentationModel : public PhysicsBase {

public:

  // Constructor.
  FragmentationModel() = default;

  virtual ~FragmentationModel() {}

  // Initialize and save pointers.
  virtual void init(StringFlav* flavSelPtrIn, StringPT* pTSelPtrIn, StringZ* zSelPtrIn,
    FragModPtr fragModPtrIn = NULL) = 0;

  // Do the fragmentation: driver routine.
  virtual bool fragment( int iSub, ColConfig& colConfig, Event& event) = 0;

  // Find the boost matrix to the rest frame of a junction.
  virtual RotBstMatrix junctionRestFrame(Vec4& p0, Vec4& p1, Vec4& p2) = 0;

protected:

};

//==========================================================================

} // end namespace Pythia8

#endif // Pythia8_FragmentationModel_H
