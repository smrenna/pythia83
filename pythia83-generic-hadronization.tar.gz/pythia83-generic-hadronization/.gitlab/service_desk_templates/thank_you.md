Your email has successfully reached the Pythia authors. When responding, reply directly to this email, which has a unique return address of the form incoming+<hash>@incoming.gitlab.com, and not authors@pythia.org.

Please consider making this correspondence publicly available to other users via https://gitlab.com/Pythia8/releases/-/issues, by replying at any point with your express permission, e.g. "this correspondence can be made public".
